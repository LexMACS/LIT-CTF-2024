// some really intensive operation here
while (true) console.log("kablewy");
